
document.getElementById("cakeScreen").addEventListener("click", () => {
  document.getElementById("cakeScreen").style.display = "none";
  document.getElementById("mainContent").style.display = "block";
});
